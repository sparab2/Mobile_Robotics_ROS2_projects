// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from a2_sp:msg/Spmsg.idl
// generated code does not contain a copyright notice

#ifndef A2_SP__MSG__DETAIL__SPMSG__BUILDER_HPP_
#define A2_SP__MSG__DETAIL__SPMSG__BUILDER_HPP_

#include "a2_sp/msg/detail/spmsg__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace a2_sp
{

namespace msg
{

namespace builder
{

class Init_Spmsg_str_msg
{
public:
  explicit Init_Spmsg_str_msg(::a2_sp::msg::Spmsg & msg)
  : msg_(msg)
  {}
  ::a2_sp::msg::Spmsg str_msg(::a2_sp::msg::Spmsg::_str_msg_type arg)
  {
    msg_.str_msg = std::move(arg);
    return std::move(msg_);
  }

private:
  ::a2_sp::msg::Spmsg msg_;
};

class Init_Spmsg_num2
{
public:
  explicit Init_Spmsg_num2(::a2_sp::msg::Spmsg & msg)
  : msg_(msg)
  {}
  Init_Spmsg_str_msg num2(::a2_sp::msg::Spmsg::_num2_type arg)
  {
    msg_.num2 = std::move(arg);
    return Init_Spmsg_str_msg(msg_);
  }

private:
  ::a2_sp::msg::Spmsg msg_;
};

class Init_Spmsg_num1
{
public:
  Init_Spmsg_num1()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Spmsg_num2 num1(::a2_sp::msg::Spmsg::_num1_type arg)
  {
    msg_.num1 = std::move(arg);
    return Init_Spmsg_num2(msg_);
  }

private:
  ::a2_sp::msg::Spmsg msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::a2_sp::msg::Spmsg>()
{
  return a2_sp::msg::builder::Init_Spmsg_num1();
}

}  // namespace a2_sp

#endif  // A2_SP__MSG__DETAIL__SPMSG__BUILDER_HPP_
