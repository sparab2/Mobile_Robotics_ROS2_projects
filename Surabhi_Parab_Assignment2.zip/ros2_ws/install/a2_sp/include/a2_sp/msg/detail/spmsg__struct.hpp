// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from a2_sp:msg/Spmsg.idl
// generated code does not contain a copyright notice

#ifndef A2_SP__MSG__DETAIL__SPMSG__STRUCT_HPP_
#define A2_SP__MSG__DETAIL__SPMSG__STRUCT_HPP_

#include <rosidl_runtime_cpp/bounded_vector.hpp>
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


#ifndef _WIN32
# define DEPRECATED__a2_sp__msg__Spmsg __attribute__((deprecated))
#else
# define DEPRECATED__a2_sp__msg__Spmsg __declspec(deprecated)
#endif

namespace a2_sp
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct Spmsg_
{
  using Type = Spmsg_<ContainerAllocator>;

  explicit Spmsg_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->num1 = 0.0;
      this->num2 = 0.0;
      this->str_msg = "";
    }
  }

  explicit Spmsg_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : str_msg(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->num1 = 0.0;
      this->num2 = 0.0;
      this->str_msg = "";
    }
  }

  // field types and members
  using _num1_type =
    double;
  _num1_type num1;
  using _num2_type =
    double;
  _num2_type num2;
  using _str_msg_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _str_msg_type str_msg;

  // setters for named parameter idiom
  Type & set__num1(
    const double & _arg)
  {
    this->num1 = _arg;
    return *this;
  }
  Type & set__num2(
    const double & _arg)
  {
    this->num2 = _arg;
    return *this;
  }
  Type & set__str_msg(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->str_msg = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    a2_sp::msg::Spmsg_<ContainerAllocator> *;
  using ConstRawPtr =
    const a2_sp::msg::Spmsg_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<a2_sp::msg::Spmsg_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<a2_sp::msg::Spmsg_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      a2_sp::msg::Spmsg_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<a2_sp::msg::Spmsg_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      a2_sp::msg::Spmsg_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<a2_sp::msg::Spmsg_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<a2_sp::msg::Spmsg_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<a2_sp::msg::Spmsg_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__a2_sp__msg__Spmsg
    std::shared_ptr<a2_sp::msg::Spmsg_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__a2_sp__msg__Spmsg
    std::shared_ptr<a2_sp::msg::Spmsg_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const Spmsg_ & other) const
  {
    if (this->num1 != other.num1) {
      return false;
    }
    if (this->num2 != other.num2) {
      return false;
    }
    if (this->str_msg != other.str_msg) {
      return false;
    }
    return true;
  }
  bool operator!=(const Spmsg_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct Spmsg_

// alias to use template instance with default allocator
using Spmsg =
  a2_sp::msg::Spmsg_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace a2_sp

#endif  // A2_SP__MSG__DETAIL__SPMSG__STRUCT_HPP_
