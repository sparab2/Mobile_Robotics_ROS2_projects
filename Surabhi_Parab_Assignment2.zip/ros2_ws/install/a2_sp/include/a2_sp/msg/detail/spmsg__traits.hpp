// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from a2_sp:msg/Spmsg.idl
// generated code does not contain a copyright notice

#ifndef A2_SP__MSG__DETAIL__SPMSG__TRAITS_HPP_
#define A2_SP__MSG__DETAIL__SPMSG__TRAITS_HPP_

#include "a2_sp/msg/detail/spmsg__struct.hpp"
#include <rosidl_runtime_cpp/traits.hpp>
#include <stdint.h>
#include <type_traits>

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<a2_sp::msg::Spmsg>()
{
  return "a2_sp::msg::Spmsg";
}

template<>
inline const char * name<a2_sp::msg::Spmsg>()
{
  return "a2_sp/msg/Spmsg";
}

template<>
struct has_fixed_size<a2_sp::msg::Spmsg>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<a2_sp::msg::Spmsg>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<a2_sp::msg::Spmsg>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // A2_SP__MSG__DETAIL__SPMSG__TRAITS_HPP_
