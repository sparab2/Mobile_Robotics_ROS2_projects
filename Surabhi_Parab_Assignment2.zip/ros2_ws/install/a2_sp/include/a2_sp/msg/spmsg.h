// generated from rosidl_generator_c/resource/idl.h.em
// with input from a2_sp:msg/Spmsg.idl
// generated code does not contain a copyright notice

#ifndef A2_SP__MSG__SPMSG_H_
#define A2_SP__MSG__SPMSG_H_

#include "a2_sp/msg/detail/spmsg__struct.h"
#include "a2_sp/msg/detail/spmsg__functions.h"
#include "a2_sp/msg/detail/spmsg__type_support.h"

#endif  // A2_SP__MSG__SPMSG_H_
