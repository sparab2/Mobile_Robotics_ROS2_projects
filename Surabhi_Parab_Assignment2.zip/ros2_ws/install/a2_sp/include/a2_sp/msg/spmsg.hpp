// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef A2_SP__MSG__SPMSG_HPP_
#define A2_SP__MSG__SPMSG_HPP_

#include "a2_sp/msg/detail/spmsg__struct.hpp"
#include "a2_sp/msg/detail/spmsg__builder.hpp"
#include "a2_sp/msg/detail/spmsg__traits.hpp"
#include "a2_sp/msg/detail/spmsg__type_support.hpp"

#endif  // A2_SP__MSG__SPMSG_HPP_
