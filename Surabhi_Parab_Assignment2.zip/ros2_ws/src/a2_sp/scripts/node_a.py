#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from a2_sp.msg import Spmsg

class PublisherNode(Node):
	def __init__(self):
	    super().__init__('node_a')
	    self.publisher_ = self.create_publisher(Spmsg, 'topic_a', 10)
	    self.timer = self.create_timer(0.1, self.timer_callback) #10Hz
	    self.count = 1
	    
	def timer_callback(self):
	    msg = Spmsg()
	    msg.num1 = float(self.count)
	    msg.num2 = float(self.count)
	    msg.str_msg = "Surabhi Parab"
	    self.publisher_.publish(msg)
	    self.count +=1
	    
def main():
    rclpy.init()
    node = PublisherNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
    
if __name__ == '__main__':
    main()
