#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from a2_sp.msg import Spmsg
from std_msgs.msg import Float64

class ProcessorNode(Node):
	def __init__(self):
	    super().__init__('node_b')
	    self.subscriber = self.create_subscription(Spmsg, 'topic_a', self.process_message, 10)
	    self.publisher = self.create_publisher(Float64, 'topic_b', 10)
	    
	def process_message(self, msg):
	    result = Float64()
	    result.data = msg.num1 + msg.num2
	    self.publisher.publish(result)
	    self.get_logger().info(f'Published to topic_b: {result.data}')
	    
def main():
    rclpy.init()
    node = ProcessorNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
    
if __name__ == '__main__':
    main()
