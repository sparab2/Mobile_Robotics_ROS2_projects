#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from a2_sp.msg import Spmsg
from std_msgs.msg import Float64

class ConsumerNode(Node):
	def __init__(self):
	    super().__init__('node_c')
	    self.subscription_a = self.create_subscription(Spmsg, 'topic_a', self.handle_topic_a, 10)
	    self.subscription_b = self.create_subscription(Float64, 'topic_b', self.handle_topic_b, 10)
	    self.latest_a = None
	    self.latest_b = None
	    self.publisher_c = self.create_publisher(Float64, 'topic_c', 10)
	    
	def handle_topic_a(self, msg):
	    self.latest_a = msg
	    self.process_data()
	    
	def handle_topic_b(self, msg):
	    self.latest_b = msg
	    self.process_data()

	def process_data(self):	    
	    if self.latest_a is not None and self.latest_b is not None:
	    	result = self.latest_a.num1 + self.latest_a.num2 - self.latest_b.data
	    	self.get_logger().info(f'Result after processing topic_a and topic_b: {result}')
	    	result_msg = Float64()
	    	result_msg.data = result
	    	self.publisher_c.publish(result_msg)
	    	
def main():
    rclpy.init()
    node = ConsumerNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
    
if __name__ == '__main__':
    main()
