#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry

class LimoOdometry(Node):
    def __init__(self):
        super().__init__('testing_limo_msgs')
        self.subscription = self.create_subscription(
            Odometry,
            'odometry',
            self.odometry_callback,
            10
        )
        
    def odometry_callback(self, msg):
    	x = msg.pose.pose.position.x
    	y = msg.pose.pose.position.y
    	self.get_logger().info(f'X: {x}, Y: {y}')
    	
def main(args=None):
    rclpy.init(args=args)
    node = LimoOdometry()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
    
if __name__ == '__main__':
    main()        

